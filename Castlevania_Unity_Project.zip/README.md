# CASTLEVANIA: TOWER DEFENSE — GOTHIC WORLD EXPANSION (Unity 2022.3 LTS)

Welcome to **Castlevania: Tower Defense**, featuring an expanded 18 × 11 gothic forest battlefield, cobblestone road, Castle Keep Gate barbican, 6 defensive towers with 3-tier visual upgrades, floating damage numbers, 30 campaign stages across 6 sectors, 6 major boss encounters, diverse tree species (Ancient Oaks, Pine Spires, Haunted Dead Trees, Silver Birches), and complete Android APK readiness.

---

## 1. Quick Start Guide (One-Click Scene Generation)

1. Open **Unity 2022.3 LTS** (or compatible 2022.3.x / 2023.x version).
2. Create a new 2D or 3D Core project, or open this extracted folder directly as an existing project.
3. Once Unity finishes importing assets and compiling scripts, go to the top menu bar:
   `Tools` -> `Castlevania` -> `Generate Gothic Forest Battlefield Scene`.
4. The editor utility automatically:
   - Configures the top-down Orthographic Main Camera (size 6.5, centered at (8.5, 5.0, -10) covering the 18 × 11 battlefield).
   - Builds the 18 × 11 gothic forest terrain with cobblestone waypoints, Castle Keep Gate, and ancient monolith spawn.
   - Spawns the `ForestEnvironmentManager` with GPU Instanced Ancient Oaks, Pine Spires, Dead Trees, Birches, ferns, and mushrooms.
   - Generates the Floating Damage Number canvas and object pool (`DamageNumberManager`).
   - Spawns the GameManager, EconomyManager, CampaignManager, WaveManager, and WaypointPath objects.
   - Builds the responsive resolution-aware Canvas with Castlevania Gothic HUD and 30-Stage Dispatch UI.
   - Generates procedural tower prefabs with distinct Level 1, 2, 3 visual indicators.
5. Press **Play** in the Unity Editor!

---

## 2. Building the Android APK (Step-by-Step)

To build the real **Castlevania.apk**:

1. In Unity, go to **File** -> **Build Settings**.
2. Select **Android** in the Platform list and click **Switch Platform**.
3. Click **Player Settings...** to verify Android settings:
   - **Company Name:** `Castlevania Studios`
   - **Product Name:** `Castlevania: Tower Defense`
   - **Package Name (Application Identifier):** `com.castlevania.towerdefense`
   - **Default Orientation:** `Landscape Left` (or `Landscape Right`)
   - **Minimum API Level:** `Android 7.0 'Nougat' (API level 24)` or higher
   - **Target API Level:** `Automatic (highest installed)`
   - **Scripting Backend:** `IL2CPP` (recommended for Google Play / 64-bit devices) or `Mono` for rapid testing
   - **Target Architectures:** Check `ARM64` and `ARMv7`
   - **Graphics API:** `Vulkan` or `OpenGLES3`
4. Ensure the Castlevania scene is checked in **Scenes in Build** (click **Add Open Scenes**).
5. In **Build Settings**, click **Build**. Choose the output file name as `Castlevania.apk`.
6. Unity and the Android Gradle wrapper will compile the C# code, package the assets, and produce the installable `Castlevania.apk`!

---

## 3. Implemented Systems

```
Assets/
├── Scripts/
│   ├── Grid/
│   │   ├── GridManager.cs            (Expanded 18x11 gothic grid mapping, 14 waypoints, tile validation)
│   │   └── GridCell.cs               (Grass/moss visuals, occupancy, hover auras)
│   ├── Environment/
│   │   └── ForestEnvironmentManager.cs (Ancient oaks, pine spires, dead trees, birches, GPU instancing)
│   ├── UI/
│   │   ├── DamageNumberManager.cs    (World-space floating damage numbers pool)
│   │   ├── FloatingDamageNumber.cs   (Smooth pop-scale, upward float & fade)
│   │   ├── StageSelectUI.cs          (30-stage campaign dispatch across 6 sectors)
│   │   └── UIManager.cs              (Castlevania HUD, build drawer, upgrade modal)
│   ├── Towers/
│   │   ├── Tower.cs                  (Autonomous targeting, level visual models)
│   │   ├── TowerData.cs              (ScriptableObject config: damage, range, fire rate)
│   │   ├── ArcherTower.cs            (Belmont ash-wood ballista with silver bolts)
│   │   ├── CannonTower.cs            (Cast-iron mortar with AOE craters)
│   │   ├── GatlingTower.cs           (Rotary gun turret)
│   │   ├── TeslaTower.cs             (Ancient runic lightning spire)
│   │   ├── FrostTower.cs             (Cryo holy water well)
│   │   ├── SniperTower.cs            (Belmont long-range railgun spire)
│   │   └── Projectile.cs             (Physics tracking, splash damage, craters)
│   ├── Enemies/
│   │   ├── Enemy.cs                  (Cobblestone path navigation, armor reduction)
│   │   ├── EnemyData.cs              (ScriptableObject stats: health, armor, speed, bounty)
│   │   ├── BossEnemy.cs              (6 Boss archetypes: War Tank, Earth Breaker, Warlord Vane, Iron Juggernaut, Storm Colossus, Supreme Titan)
│   │   └── WaypointPath.cs           (14 Vector3 waypoints interpolation & gizmos)
│   ├── Managers/
│   │   ├── GameManager.cs            (Lives, state machine: Title, Playing, Victory, Defeat)
│   │   ├── EconomyManager.cs         (Gold balance, spend/refund economics)
│   │   ├── CampaignManager.cs        (30 stages, 6 sectors, progressive difficulty)
│   │   └── WaveManager.cs            (Wave spawning queues, intervals, boss injection)
│   └── Editor/
│       └── CastlevaniaSceneBuilder.cs (One-click complete 18x11 Gothic Forest scene builder)
├── ProjectSettings/
│   └── ProjectSettings.asset
└── Packages/
    └── manifest.json
```
