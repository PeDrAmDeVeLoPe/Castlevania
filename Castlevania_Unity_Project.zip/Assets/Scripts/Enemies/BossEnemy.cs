using UnityEngine;

namespace Castlevania.Enemies
{
    public class BossEnemy : MonoBehaviour
    {
        public enum BossArchetype
        {
            WarTank,
            SiegeColossus,
            WarCommander,
            IronJuggernaut,
            StormColossus,
            SupremeTitan
        }

        public BossArchetype Archetype { get; private set; }
        public bool IsShieldActive { get; private set; } = false;
        public bool IsEnraged { get; private set; } = false;

        private float abilityTimer = 0f;

        public void InitializeBoss(BossArchetype archetype, float maxHp, float armor, float speed)
        {
            Archetype = archetype;
            abilityTimer = 0f;
            Debug.Log($"[Castlevania] Major Boss Spawned: {archetype} (HP: {maxHp}, Armor: {armor})");
        }

        private void Update()
        {
            abilityTimer += Time.deltaTime;
            ExecuteArchetypeAbility();
        }

        private void ExecuteArchetypeAbility()
        {
            switch (Archetype)
            {
                case BossArchetype.WarTank:
                    // Deflection shield every 8s for 3s
                    IsShieldActive = (abilityTimer % 8f) < 3f;
                    break;

                case BossArchetype.IronJuggernaut:
                    // Reactive armor hardening
                    break;

                case BossArchetype.SupremeTitan:
                    // Forcefield + Enraged sprint
                    IsShieldActive = (abilityTimer % 7f) < 3.5f;
                    break;
            }
        }
    }
}
