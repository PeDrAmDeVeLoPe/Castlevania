using UnityEngine;

namespace Castlevania.Environment
{
    public class ForestEnvironmentManager : MonoBehaviour
    {
        public enum TreeType { AncientOak, PineSpire, HauntedDead, Birch, YoungOak }

        [Header("Performance Settings")]
        [SerializeField] private bool enableGpuInstancing = true;

        private void Start()
        {
            SpawnDiverseForestPerimeter();
        }

        public void SpawnDiverseForestPerimeter()
        {
            // Perimeter clusters surrounding 18x11 world
            Vector3[] oakPositions = new Vector3[]
            {
                new Vector3(-1.5f, 2f, 0), new Vector3(5f, -1.8f, 0),
                new Vector3(14f, -1.8f, 0), new Vector3(19f, 4f, 0),
                new Vector3(8f, 12f, 0), new Vector3(16f, 12f, 0)
            };

            foreach (var pos in oakPositions)
            {
                CreateTree(pos, TreeType.AncientOak, 1.3f);
            }

            Vector3[] pinePositions = new Vector3[]
            {
                new Vector3(-1.8f, 7f, 0), new Vector3(1f, -1.8f, 0),
                new Vector3(10f, -1.8f, 0), new Vector3(19f, 9f, 0),
                new Vector3(3f, 12f, 0), new Vector3(12f, 12f, 0)
            };

            foreach (var pos in pinePositions)
            {
                CreateTree(pos, TreeType.PineSpire, 1.15f);
            }

            Vector3[] deadPositions = new Vector3[]
            {
                new Vector3(-1.5f, 5f, 0), new Vector3(18.5f, 2f, 0),
                new Vector3(18.5f, 11f, 0), new Vector3(0.5f, 12f, 0)
            };

            foreach (var pos in deadPositions)
            {
                CreateTree(pos, TreeType.HauntedDead, 1.2f);
            }
        }

        private GameObject CreateTree(Vector3 position, TreeType type, float scale)
        {
            GameObject treeObj = new GameObject($"Tree_{type}_{position.x}_{position.y}");
            treeObj.transform.parent = transform;
            treeObj.transform.position = position;
            treeObj.transform.localScale = Vector3.one * scale;

            SpriteRenderer sr = treeObj.AddComponent<SpriteRenderer>();
            Texture2D tex = new Texture2D(32, 32);
            Color baseColor = type == TreeType.AncientOak ? new Color(0.1f, 0.35f, 0.15f) :
                              type == TreeType.PineSpire ? new Color(0.08f, 0.25f, 0.12f) :
                              type == TreeType.HauntedDead ? new Color(0.2f, 0.15f, 0.1f) :
                              new Color(0.15f, 0.45f, 0.2f);

            for (int x = 0; x < 32; x++)
            {
                for (int y = 0; y < 32; y++)
                {
                    tex.SetPixel(x, y, baseColor);
                }
            }
            tex.Apply();
            sr.sprite = Sprite.Create(tex, new Rect(0, 0, 32, 32), new Vector2(0.5f, 0.5f));
            sr.sortingOrder = 5;

            if (enableGpuInstancing)
            {
                Material mat = new Material(Shader.Find("Sprites/Default"));
                mat.enableInstancing = true;
                sr.material = mat;
            }

            return treeObj;
        }
    }
}
