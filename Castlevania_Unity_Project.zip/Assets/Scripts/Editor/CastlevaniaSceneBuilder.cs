#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using Castlevania.Grid;
using Castlevania.Environment;
using Castlevania.Managers;

namespace Castlevania.Editor
{
    public static class CastlevaniaSceneBuilder
    {
        [MenuItem("Tools/Castlevania/Generate Gothic Forest Battlefield Scene")]
        public static void GenerateScene()
        {
            // 1. Camera (Centered for 18x11 grid)
            Camera mainCam = Camera.main;
            if (mainCam == null)
            {
                GameObject camObj = new GameObject("Main Camera");
                mainCam = camObj.AddComponent<Camera>();
                camObj.tag = "MainCamera";
            }
            mainCam.orthographic = true;
            mainCam.orthographicSize = 6.5f;
            mainCam.transform.position = new Vector3(8.5f, 5.0f, -10f);
            mainCam.backgroundColor = new Color(0.05f, 0.12f, 0.07f);

            // 2. Managers
            GameObject mgrs = new GameObject("Managers");
            mgrs.AddComponent<CampaignManager>();

            // 3. Environment & Grid
            GameObject env = new GameObject("Environment");
            env.AddComponent<ForestEnvironmentManager>();

            GameObject grid = new GameObject("GridManager");
            grid.AddComponent<GridManager>();

            Debug.Log("[Castlevania: Tower Defense] 18x11 Gothic Forest Scene successfully generated! Press Play to defend the Castle Keep.");
        }
    }
}
#endif
