using UnityEngine;

namespace Castlevania.Managers
{
    public class CampaignManager : MonoBehaviour
    {
        public int CurrentStage { get; private set; } = 1;
        public int HighestUnlockedStage { get; private set; } = 1;

        public void LoadStage(int stage)
        {
            CurrentStage = Mathf.Clamp(stage, 1, 30);
            Debug.Log($"[Castlevania] Loaded Campaign Stage {CurrentStage}");
        }

        public void CompleteStage(int stars)
        {
            if (CurrentStage == HighestUnlockedStage && HighestUnlockedStage < 30)
            {
                HighestUnlockedStage++;
            }
            Debug.Log($"[Castlevania] Stage {CurrentStage} cleared with {stars} Stars! Highest Unlocked: {HighestUnlockedStage}");
        }
    }
}
