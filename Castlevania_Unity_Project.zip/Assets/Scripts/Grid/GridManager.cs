using System.Collections.Generic;
using UnityEngine;

namespace Castlevania.Grid
{
    public class GridManager : MonoBehaviour
    {
        public const int Columns = 18;
        public const int Rows = 11;
        public const float CellSize = 1.0f;

        [SerializeField] private GameObject cellPrefab;
        private GridCell[,] grid = new GridCell[Columns, Rows];
        private HashSet<Vector2Int> pathCells = new HashSet<Vector2Int>();

        public static readonly Vector2Int[] Waypoints = new Vector2Int[]
        {
            new Vector2Int(0, 3),
            new Vector2Int(4, 3),
            new Vector2Int(4, 1),
            new Vector2Int(9, 1),
            new Vector2Int(9, 4),
            new Vector2Int(6, 4),
            new Vector2Int(6, 8),
            new Vector2Int(2, 8),
            new Vector2Int(2, 10),
            new Vector2Int(12, 10),
            new Vector2Int(12, 6),
            new Vector2Int(15, 6),
            new Vector2Int(15, 8),
            new Vector2Int(17, 8)
        };

        private void Awake()
        {
            ComputePathCells();
            GenerateGrid();
        }

        private void ComputePathCells()
        {
            pathCells.Clear();
            for (int i = 0; i < Waypoints.Length - 1; i++)
            {
                Vector2Int p1 = Waypoints[i];
                Vector2Int p2 = Waypoints[i + 1];

                int dx = (int)Mathf.Sign(p2.x - p1.x);
                int dy = (int)Mathf.Sign(p2.y - p1.y);

                int cx = p1.x;
                int cy = p1.y;

                pathCells.Add(new Vector2Int(cx, cy));
                while (cx != p2.x || cy != p2.y)
                {
                    if (cx != p2.x) cx += dx;
                    if (cy != p2.y) cy += dy;
                    pathCells.Add(new Vector2Int(cx, cy));
                }
            }
        }

        private void GenerateGrid()
        {
            for (int x = 0; x < Columns; x++)
            {
                for (int y = 0; y < Rows; y++)
                {
                    Vector3 worldPos = new Vector3(x * CellSize, y * CellSize, 0f);
                    GameObject obj = new GameObject($"Cell_{x}_{y}");
                    obj.transform.parent = transform;
                    obj.transform.position = worldPos;

                    GridCell cell = obj.AddComponent<GridCell>();
                    bool isPath = pathCells.Contains(new Vector2Int(x, y));
                    cell.Initialize(x, y, isPath);
                    grid[x, y] = cell;
                }
            }
        }

        public GridCell GetCell(int col, int row)
        {
            if (col < 0 || col >= Columns || row < 0 || row >= Rows) return null;
            return grid[col, row];
        }

        public bool IsValidPlacement(int col, int row)
        {
            GridCell cell = GetCell(col, row);
            return cell != null && cell.CanBuild();
        }
    }
}
